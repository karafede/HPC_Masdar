rm ./*.out
rm ./*.err